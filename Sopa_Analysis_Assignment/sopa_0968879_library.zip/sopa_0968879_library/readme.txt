
Name: Tenzin Sopa Jitsang
Student nr. 0968879
Programing language c#


<User manual>
command prompt commands: 

quit ...............= exiting the program
upload books .......= uploading books from a JSON file 
upload customers ...= uploading customers from a CSV file 
add book ...........= adding a new book
add customer .......= adding a new customer
search .............= searching books
loan a book ........= lending a book to a customer 
backup .............= backing up all the data 
restore ............= restoring backed up data
loan list ..........= list of all the book that are on loan
list customers .....= print all customers
list books .........= print all books