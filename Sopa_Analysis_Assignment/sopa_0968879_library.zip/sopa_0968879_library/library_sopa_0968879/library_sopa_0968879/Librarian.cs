﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace library_sopa_0968879
{
    class Librarian
    {
        [JsonProperty]
        private Dictionary<int, int> LoanedBooks = new Dictionary<int, int>(); //Dictionary with   key= book_Id   value = custoemr_id
        public void Lend(int customerId, int bookId)
        {
            if (!LoanedBooks.ContainsKey(bookId))
            {
                LoanedBooks.Add(bookId, customerId);
            }
            else
            {
                Console.WriteLine("This book is loaned to someone else write now");
            }

        }
        public void GetAllBooksOnLoan(List<BookItem> books, List<Customer> customers)
        {
            Console.WriteLine(" \nThese books are on loan:\n");
            foreach (var book in books)
            {
                foreach (int id in LoanedBooks.Keys)
                {
                    if (book.Id == id)
                        Console.WriteLine(" Book Id: " + book.Id + " Book title: " + book.Title + "\n Borrowed by Customer Id: " + customers[LoanedBooks[id]].Id + " Customer surname: " + customers[LoanedBooks[id]].Surname + "\n");
                }

            }
        }
        public void Backup(Librarian loanedBooksRegister)
        {
            String currentDicrectory = Directory.GetCurrentDirectory();
            DirectoryInfo directory = new DirectoryInfo(currentDicrectory);
            var BookshelfFileName = Path.Combine(directory.FullName, "backupLoanedBooksRegister.json");
            var Bookshelfserializer = new JsonSerializer();
            using (var writer = new StreamWriter(BookshelfFileName))
            using (var jsonWriter = new JsonTextWriter(writer))
            {
                Bookshelfserializer.Serialize(jsonWriter, loanedBooksRegister);
            }
        }
    }


}
