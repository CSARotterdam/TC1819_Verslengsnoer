﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace library_sopa_0968879
{
    class Bookshelf
    {
        public List<BookItem> Books = new List<BookItem>();


        public void PrintAllBooks()
        {
            foreach (var book in Books)
            {
                Console.WriteLine(book.ToString());
            }
        }
        public List<Book> SearchBooksWithTitle(string title)
        {
            List<Book> searchResult = new List<Book>();
            foreach (var book in Books)
            {
                if (book.Title == title)
                {
                    searchResult.Add(book);
                }
            }
            return searchResult;
        }
        public List<BookItem> SearchBooksOfAuthor(string author)
        {
            List<BookItem> searchResult = new List<BookItem>();
            foreach (var book in Books)
            {
                if (book.Author == author)
                {
                    searchResult.Add(book);
                }
            }
            return searchResult;
        }
        public Book SearchBooksOfAuthorWithTitle(string title, string author)
        {
            foreach (var book in Books)
            {
                if (book.Author == author && book.Title == title)
                {
                    return book;
                }
            }
            return null;
        }

        public void UploadBooks(String filePath)
        {
            var books = new List<Book>();
            var serializer = new JsonSerializer();
            using (var reader = new StreamReader(filePath))
            using (var jsonReader = new JsonTextReader(reader))
            {
                this.Books = serializer.Deserialize<List<BookItem>>(jsonReader);
            }
        }
        public void AddBook(BookItem book)
        {
            this.Books.Add(book);
        }
        public void Backup(Bookshelf bookshelf)
        {
            String currentDicrectory = Directory.GetCurrentDirectory();
            DirectoryInfo directory = new DirectoryInfo(currentDicrectory);
            var BookshelfFileName = Path.Combine(directory.FullName, "backupBookshelf.json");
            var Bookshelfserializer = new JsonSerializer();
            using (var writer = new StreamWriter(BookshelfFileName))
            using (var jsonWriter = new JsonTextWriter(writer))
            {
                Bookshelfserializer.Serialize(jsonWriter, bookshelf);
            }
        }

    }

}
