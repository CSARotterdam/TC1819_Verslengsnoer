﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace library_sopa_0968879
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomerRegister customerRegister = new CustomerRegister();
            Bookshelf bookshelf = new Bookshelf();
            Librarian librarian = new Librarian();
            bool quit = false;
            string userCommand = "";
            bool bookhelfFilled = false;
            bool customerRegisterfFilled = false;
            Console.WriteLine(" Enter help for more information");

            while (quit == false)
            {
                Console.WriteLine(" How can I help you? :)");
                userCommand = Console.ReadLine();

                if (userCommand == "quit")
                {
                    quit = true;
                }
                else if (userCommand == "upload books")
                {
                    Console.WriteLine(" Enter your json file <path>/<fileName>.json \n Example: C:\\Users\\tensopa\\Desktop\\booksset1.json");
                    userCommand = Console.ReadLine();
                    var filePath = @userCommand;
                    try
                    {
                        bookshelf.UploadBooks(filePath);
                        bookshelf.PrintAllBooks();
                        bookhelfFilled = true;
                        Console.WriteLine(" books have been successfully uploaded :)\n");
                    }
                    catch 
                    {
                        Console.WriteLine(" this path is not valid");

                    }

                }
                else if (userCommand == "add book")
                {
                    try
                    {
                        Console.WriteLine(" please enter the book attributes in this order and each value separated by one spacebar:  \ntitle author country imageLink link pages year\n");
                        String[] bookValues = new String[7];
                        bookValues = Console.ReadLine().Split(' ');
                        bookshelf.AddBook(new BookItem(bookValues[0], bookValues[1], bookValues[2], bookValues[3], bookValues[4], Int32.Parse(bookValues[5]), Int32.Parse(bookValues[6])));
                        bookhelfFilled = true;
                        Console.WriteLine(" New book has been successfully added \n");

                    }
                    catch
                    {
                        Console.WriteLine(" Your entry is incorrect ");
                    }
                }
                else if (userCommand == "list books")
                {
                        bookshelf.PrintAllBooks();
                }

                else if (userCommand == "search")
                {
                    if (customerRegisterfFilled || bookhelfFilled)
                    {
                        Console.WriteLine(" what do you want to search \nenter b for book \nenter c for customer");
                        userCommand = Console.ReadLine();
                        if (userCommand == "b")
                        {
                            Console.WriteLine(" How do you want to search your book?\n enter t for title\n enter a for author\n enter t a for title and author");
                            userCommand = Console.ReadLine();
                            if (userCommand == "t")
                            {
                                Console.WriteLine(" Enter the book title");
                                userCommand = Console.ReadLine();
                                if (bookshelf.SearchBooksWithTitle(userCommand).Count > 0)
                                {
                                    Console.WriteLine(" Search result: \n");
                                    foreach (var book in bookshelf.SearchBooksWithTitle(userCommand))
                                    {
                                        Console.WriteLine(book.ToString());
                                    }
                                }

                            }
                            else if (userCommand == "a")
                            {
                                Console.WriteLine(" Enter the author name");
                                userCommand = Console.ReadLine();
                                if (bookshelf.SearchBooksOfAuthor(userCommand).Count > 0)
                                {
                                    Console.WriteLine(" Search result: \n");
                                    foreach (var book in bookshelf.SearchBooksOfAuthor(userCommand))
                                    {
                                        Console.WriteLine(book.ToString());
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" there is no book with author: " + userCommand);

                                }

                            }
                            else if (userCommand == "t a")
                            {
                                Console.WriteLine(" Enter the book title");
                                string tile = Console.ReadLine();
                                Console.WriteLine(" Enter the author name");
                                string author = Console.ReadLine();

                                if (bookshelf.SearchBooksOfAuthorWithTitle(tile, author) != null)
                                {
                                    Console.WriteLine(" Search result: \n");
                                    bookshelf.SearchBooksOfAuthorWithTitle(tile, author).ToString();
                                }
                                else
                                {
                                    Console.WriteLine(" there is no book with title: " + tile + " author: " + author);
                                }

                            }
                            else
                            {
                                Console.WriteLine(" this input is not valid\n");
                            }
                        }

                    }
                    else
                    {
                        Console.WriteLine(" bookshelf is empty at the moment and they are no customer\n");
                    }

                }
                else if (userCommand == "upload customers")
                {
                    Console.WriteLine(" Enter your CSV file <path>/<fileName>.csv \n Example: C:\\Users\\tensopa\\Desktop\\FakeNameSet20.csv\n");
                    userCommand = Console.ReadLine();
                    customerRegister.UploadCustomerCsv(@userCommand);
                }
                else if (userCommand == "add customer")
                {
                    try
                    {
                        Console.WriteLine(" please enter the book attributes in this order and each value separated by one spacebar:  \nnumber gender nameSet surname streetAddress zipCode city emailAddress userName telephoneNumbe\n");
                        String[] cutomerValues = new String[10];
                        cutomerValues = Console.ReadLine().Split(' ');
                        customerRegister.AddCustomer(new Customer(Int32.Parse(cutomerValues[0]), cutomerValues[1], cutomerValues[2], cutomerValues[3], cutomerValues[4], cutomerValues[4], cutomerValues[4], cutomerValues[4], cutomerValues[5], cutomerValues[5]));
                        Console.WriteLine("\n successfully added a new customer\n");

                    }
                    catch
                    {
                        Console.WriteLine("Your entry is incorrect ");
                    }
                }
                else if (userCommand == "list customers")
                {
                        customerRegister.PrintAllCustomers();
                }
                else if (userCommand == "loan a book")
                {
                    if (bookhelfFilled)
                    {
                        try
                        {
                            bookshelf.PrintAllBooks();
                            Console.WriteLine("\n Enter the ID of the book listed above that you want to loan to a customer\n");
                            BookItem book = bookshelf.Books[Int32.Parse(Console.ReadLine())];
                            customerRegister.PrintAllCustomers();
                            Console.WriteLine("\n Enter the ID of the customer mentioned above to whom you want to lend that book\n");
                            Customer customer = customerRegister.GetCustomer(Int32.Parse(Console.ReadLine()));
                            librarian.Lend(customer.Id, book.Id);
                            Console.WriteLine("\n book: " + book.Title + " has been successfully loaned to customer: " + customer.Surname + "\n");

                        }
                        catch
                        {
                            Console.WriteLine(" Your entry is incorrect\n");
                        }

                    }
                    else
                    {
                        Console.WriteLine(" Library is empty write now\n");
                    }
                }
                else if (userCommand == "loan list")
                {
                    librarian.GetAllBooksOnLoan(bookshelf.Books, customerRegister.GetAllCustomers());

                }

                else if (userCommand == "backup")
                {
                    String currentDicrectory = Directory.GetCurrentDirectory();
                    DirectoryInfo directory = new DirectoryInfo(currentDicrectory);
                    customerRegister.Backup(customerRegister);
                    bookshelf.Backup(bookshelf);
                    librarian.Backup(librarian);
                    Console.WriteLine(" System Backup is successful\n You can find the backed up json files in this folder:\n " + directory.FullName + "\n");

                }
                else if (userCommand == "restore")
                {
                    try
                    {
                        String currentDicrectory = Directory.GetCurrentDirectory();
                        DirectoryInfo directory = new DirectoryInfo(currentDicrectory);
                        var BookshelfFileName = Path.Combine(directory.FullName, "backupBookshelf.json");
                        var serializer = new JsonSerializer();
                        using (var reader = new StreamReader(BookshelfFileName))
                        using (var jsonReader = new JsonTextReader(reader))
                        {
                            bookshelf = serializer.Deserialize<Bookshelf>(jsonReader);
                        }
                        BookshelfFileName = Path.Combine(directory.FullName, "backupCustomerRegister.json");
                        using (var reader = new StreamReader(BookshelfFileName))
                        using (var jsonReader = new JsonTextReader(reader))
                        {
                            customerRegister = serializer.Deserialize<CustomerRegister>(jsonReader);
                        }
                        BookshelfFileName = Path.Combine(directory.FullName, "backupLoanedBooksRegister.json");
                        using (var reader = new StreamReader(BookshelfFileName))
                        using (var jsonReader = new JsonTextReader(reader))
                        {
                            librarian = serializer.Deserialize<Librarian>(jsonReader);
                        }
                        bookhelfFilled = true;
                        customerRegisterfFilled = true;
                        Console.WriteLine(" System has been successfully restored\n");

                    }
                    catch
                    {
                        Console.WriteLine(" You hvave to first backup before you can restore \n");

                    }
                }
                else if (userCommand == "help")
                {
                    Console.WriteLine("\n <command> = <fucntion>\n\n quit = exiting the program \n upload books = uploading books from a JSON file \n upload customers = uploading customers from a CSV file \n " +
                        "add book = adding a new book \n add customer = adding a new customer \n search = searching books \n loan a book = lending a book to a customer \n" +
                        " backup = backing up all the data \n restore = restoring backed up data\n loan list = list of all the book that are on loan\n list customers = print all customers\n list books = print all books\n");

                }
                else
                {
                    Console.WriteLine(" this input is not valid\n");

                }
            }


        }
    }
}
