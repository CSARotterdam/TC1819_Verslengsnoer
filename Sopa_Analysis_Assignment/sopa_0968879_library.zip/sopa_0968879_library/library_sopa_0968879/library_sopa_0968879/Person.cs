﻿using System;
namespace library_sopa_0968879
{
    abstract class Person
    {
        public int Number { get; protected set; }
        public string Gender { get; protected set; }
        public string Surname { get; protected set; }
        public int Id { get; protected set; }
        protected static int Count = 0;

        public Person(int number, string gender, string surname)
        {
            this.Number = number;
            this.Surname = surname;
            this.Gender = gender;
        }


    }

}
