﻿using System;
namespace library_sopa_0968879
{
    class BookItem : Book
    {
        public int Id { get; private set; }
        public static int Count = 0;
        public BookItem(string title, string author, string country, string imageLink, string link, int pages, int year)
            : base(title, author, country, imageLink, link, pages, year)
        {
            this.Id = Count++;
        }
        public override string ToString()
        {
            return "Book Id: " + Id + "\nTitle: " + Title + "\nAuthor: " + Author + "\nYear: " + year + "\n";
        }
    }

}
