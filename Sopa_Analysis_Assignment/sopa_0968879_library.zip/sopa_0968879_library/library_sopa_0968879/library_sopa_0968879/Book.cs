﻿using System;
namespace library_sopa_0968879
{
    abstract class Book
    {
        public string Title { get; private set; }
        public string Author { get; private set; }
        public string Country { get; private set; }
        public string ImageLink { get; private set; }
        public string Link { get; private set; }
        public int Pages { get; private set; }
        public int year { get; private set; }

        public Book(string title, string author, string country, string imageLink, string link, int pages, int year)
        {
            this.Title = title;
            this.Author = author;
            this.Country = country;
            this.ImageLink = imageLink;
            this.Link = link;
            this.Pages = pages;
            this.year = year;
        }


    }

}
