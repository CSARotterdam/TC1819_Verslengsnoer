﻿using System;
namespace library_sopa_0968879
{
    class Customer : Person
    {
        public string NameSet { get; protected set; }
        public string StreetAddress { get; protected set; }
        public string ZipCode { get; protected set; }
        public string City { get; protected set; }
        public string EmailAddress { get; protected set; }
        public string UserName { get; protected set; }
        public string TelephoneNumber { get; protected set; }

        public Customer(int number, string gender, string nameSet, string surname, string streetAddress,
            string zipCode, string city, string emailAddress, string userName, string telephoneNumber) : base(number, gender, surname)
        {
            this.Id = Count++;
            this.NameSet = nameSet;
            this.StreetAddress = streetAddress;
            this.ZipCode = zipCode;
            this.City = city;
            this.EmailAddress = emailAddress;
            this.UserName = userName;
            this.TelephoneNumber = telephoneNumber;

        }


    }

}
