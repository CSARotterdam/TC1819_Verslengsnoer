﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace library_sopa_0968879
{
    class CustomerRegister
    {
        [JsonProperty]
        private List<Customer> Customers = new List<Customer>();

        public CustomerRegister()
        {

        }

        public void UploadCustomerCsv(String filePath)
        {
            var fileContents = new List<string[]>();
            try
            {
                using (var reader = new StreamReader(filePath))
                {
                    string line = "";
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] values = line.Split(',');
                        fileContents.Add(values);
                    }
                }
            }
            catch
            {
                Console.WriteLine("this path is not valid");
            }
            for (var i = 1; i < fileContents.Count; i++)
            {
                Customers.Add(new Customer(Int32.Parse(fileContents[i][0]), fileContents[i][1], fileContents[i][2], fileContents[i][3], fileContents[i][4], fileContents[i][0], fileContents[i][5], fileContents[i][6], fileContents[i][7], fileContents[i][8]));
            }
            foreach (var Customer in Customers)
            {
                Console.WriteLine(Customer.Surname);

            }
        }

        public void AddCustomer(Customer customer)
        {
            Customers.Add(customer);
        }
        public void PrintAllCustomers()
        {
            foreach (var Customer in Customers)
            {
                Console.WriteLine(" Id: " + Customer.Id + " SurName: " + Customer.Surname + "\n");

            }
        }
        public List<Customer> GetAllCustomers()
        {
            return Customers;
        }

        public Customer GetCustomer(int i)
        {
            return Customers[i];
        }
        public void Backup(CustomerRegister customerRegister)
        {
            String currentDicrectory = Directory.GetCurrentDirectory();
            DirectoryInfo directory = new DirectoryInfo(currentDicrectory);
            var CustomerRegisterfileName = Path.Combine(directory.FullName, "backupCustomerRegister.json");
            var CustomerRegisterserializer = new JsonSerializer();
            using (var writer = new StreamWriter(CustomerRegisterfileName))
            using (var jsonWriter = new JsonTextWriter(writer))
            {
                CustomerRegisterserializer.Serialize(jsonWriter, customerRegister);
            }
        }


    }


}
